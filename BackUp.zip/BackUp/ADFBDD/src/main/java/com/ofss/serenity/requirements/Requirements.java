package com.ofss.serenity.requirements;

import net.thucydides.core.annotations.Feature;

public class Requirements {


    @Feature
    public class BussinessConfig {
        public class Homeloan2 {};
    }
    
    @Feature
    public class Documents {
        public class Homeloan {};
    }


}
