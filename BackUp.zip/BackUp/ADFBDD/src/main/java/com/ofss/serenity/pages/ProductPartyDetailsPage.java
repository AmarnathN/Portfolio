package com.ofss.serenity.pages;

import net.serenitybdd.core.pages.PageObject;

public class ProductPartyDetailsPage extends PageObject {


}
