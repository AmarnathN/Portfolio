package com.pages;

import org.openqa.selenium.WebDriver;

public class ProductPartyDetailsPage {

	




}
