package com.ofss.pages;

import org.openqa.selenium.WebDriver;

public class ProductPartyDetailsPage {

	




}
